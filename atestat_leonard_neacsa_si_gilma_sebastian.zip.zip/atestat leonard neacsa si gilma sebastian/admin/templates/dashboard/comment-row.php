<div class="comment text-small">
	<div class="row-1">
		<span class="text-semibold"><?php echo $name ?></span>
		<span><?php echo $title ?></span>
		<span class="text-light text-right"><?php echo date("d/m/Y", strtotime($timestamp)) ?></span>
	</div>
	<div class="row-2"><?php echo $body ?></div>
</div>
