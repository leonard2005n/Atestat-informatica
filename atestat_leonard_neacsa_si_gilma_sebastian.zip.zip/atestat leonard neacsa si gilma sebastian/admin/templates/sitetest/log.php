<div class="padding-left margin-top-2 border-bottom-2 border-mute-light fore-color-1">Email Log</div>
<div>
	<textarea class="margin-top-2" readonly="true" style="width: 99%; height: 200px;"><?php echo $log ?></textarea>
</div>
