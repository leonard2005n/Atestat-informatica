<?php

// Users data
$imSettings['access']['webregistrations_gid'] = '9c6bgh1m';
$imSettings['access']['users'] = array(
	'hejomed887@haislot.com' => array(
		'groups' => array('rw4mwuiu'),
		'id' => '3uwpe9te',
		'firstname' => 'Admin',
		'lastname' => '',
		'password' => '6jxjg5i0',
		'email' => 'hejomed887@haislot.com',
		'page' => false
	)
);

// Admins list
$imSettings['access']['admins'] = array('3uwpe9te');

// Page/Users permissions
$imSettings['access']['pages'] = array();

// End of file access.inc.php